<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user_id=auth()->user()->id;
        $profile=DB::table('users')
            ->select('users.*')
            ->where('id',$user_id)
            ->first();

        return view('home', ['profile'=>$profile]);
    }

    public function profile(Request $request){
        $this->validate($request, [
            'present_location' => ['required'],
            'prefered_location' => ['required'],
            'education' => ['required'],
            'collage_education'=>['required'],
            'stream' => ['required'],
            'passed_out' => ['required'],
            'cgp' => ['required'],
            'collage_name' => ['required'],
            'city' => ['required']
            
        ]);

        $user_id=auth()->user()->id;

        if(auth()->user()->user_type=='Fresher'){

        $insert=DB::table('profile')
            ->insert([
                'user_id'=>$user_id,
                'present_location'=>$request->present_location,
                'prefered_location'=>$request->prefered_location,
                'education_details'=>$request->education,
                'collage_education'=>$request->collage_education,
                'stream'=>$request->stream,
                'passed_out_year'=>$request->passed_out,
                'cgp'=>$request->cgp,
                'collage_name'=>$request->collage_name,
                'city'=>$request->city,
                'created_at'=>now(),
                'updated_at'=>now()
            ]);

        }else{
            $insert=DB::table('profile')
            ->insert([
                'user_id'=>$user_id,
                'present_location'=>$request->present_location,
                'prefered_location'=>$request->prefered_location,
                'education_details'=>$request->education,
                'collage_education'=>$request->collage_education,
                'stream'=>$request->stream,
                'passed_out_year'=>$request->passed_out,
                'cgp'=>$request->cgp,
                'collage_name'=>$request->collage_name,
                'city'=>$request->city,
                'company_details'=>$request->company_details,
                'company_name'=>$request->company_name,
                'role'=>$request->role,
                'joining_date'=>$request->joining_date,
                'skills'=>$request->skills,
                'created_at'=>now(),
                'updated_at'=>now()

            ]);
        }

        return redirect('home')->with('success','Profile is added successfully');            

    }
}
