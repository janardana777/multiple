@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">User Profile <span style="float: right;">{{ auth()->user()->user_type}}</span></div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    @if (session()->has('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session()->get('success') }}
                        </div>
                    @endif                    

                     <form method="POST" action="{{ route('profile') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ $profile->name }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="contact" class="col-md-4 col-form-label text-md-right">Contact</label>

                            <div class="col-md-6">
                                <input id="contact" type="text" class="form-control @error('contact') is-invalid @enderror" name="contact" value="{{ $profile->contact }}" required autocomplete="contact" autofocus>

                                @error('contact')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $profile->email }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="present_location" class="col-md-4 col-form-label text-md-right">Present Location</label>

                            <div class="col-md-6">
                                <input id="person_location" type="text" class="form-control @error('persent_location') is-invalid @enderror" name="present_location" required autocomplete="new-password">

                                @error('present_location')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="prefered_location" class="col-md-4 col-form-label text-md-right">Prefered Location</label>

                            <div class="col-md-6">
                                <input id="prefered_location" type="text" class="form-control @error('prefered_location') is-invalid @enderror" name="prefered_location" required autocomplete="new-password">

                                @error('prefered_location')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="education" class="col-md-4 col-form-label text-md-right">Education detail</label>

                            <div class="col-md-6">
                                <input id="education" type="text" class="form-control @error('education') is-invalid @enderror" name="education" required autocomplete="new-password">

                                @error('education')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="collage_education" class="col-md-4 col-form-label text-md-right">Collage Education</label>

                            <div class="col-md-6">
                                <input id="collage_education" type="text" class="form-control @error('collage_education') is-invalid @enderror" name="collage_education" required autocomplete="new-password">

                                @error('collage_education')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="stream" class="col-md-4 col-form-label text-md-right">Stream</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="stream" required autocomplete="new-password">
                                @error('stream')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="passed_out" class="col-md-4 col-form-label text-md-right">Passed out year</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="passed_out" required autocomplete="new-password">
                                @error('passed_out')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="cgp" class="col-md-4 col-form-label text-md-right">CGP</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="cgp" required autocomplete="new-password">
                                @error('cgp')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="collage_name" class="col-md-4 col-form-label text-md-right">Collage Name</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="collage_name" required autocomplete="new-password">
                                @error('collage_name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="city" class="col-md-4 col-form-label text-md-right">City</label>

                            <div class="col-md-6">
                                <select id="user_type" class="form-control @error('city') is-invalid @enderror" name="city" required >
                                    <?php $city=DB::Table('city')
                                    ->select('city.*')
                                    ->get();

                                    foreach($city as $cities){ ?>
                                    <option value="{{$cities->id}}">{{$cities->name}}</option>
                                    <?php } ?>
                                </select>   

                                @error('city')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <?php if(auth()->user()->user_type=='Experienced'){ ?>
                        <div class="form-group row">
                            <label for="company_details" class="col-md-4 col-form-label text-md-right">Company Details</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="company_details" required autocomplete="new-password">
                                @error('company_details')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="company_name" class="col-md-4 col-form-label text-md-right">Company Name</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="company_name" required autocomplete="new-password">
                                @error('company_name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="role" class="col-md-4 col-form-label text-md-right">Role</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="role" required autocomplete="new-password">
                                @error('role')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="joining_date" class="col-md-4 col-form-label text-md-right">Joining Date</label>

                            <div class="col-md-6">
                                <input id="" type="date" class="form-control" name="joining_date" required autocomplete="new-password">
                                @error('joining_date')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="skills" class="col-md-4 col-form-label text-md-right">Skills</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="skills" required autocomplete="new-password">
                                @error('skills')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                    <?php } ?>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
