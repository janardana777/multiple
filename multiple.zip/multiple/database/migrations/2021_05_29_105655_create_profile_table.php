<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProfileTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('profile', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('user_id');
            $table->string('present_location');
            $table->string('prefered_location');
            $table->string('education_details');
            $table->string('collage_education');
            $table->string('stream');
            $table->string('passed_out_year');
            $table->string('cgp');
            $table->string('collage_name');
            $table->string('city');
            $table->string('company_details')->nullable();
            $table->string('joining_details')->nullable();
            $table->string('company_name')->nullable();
            $table->string('role')->nullable();
            $table->string('joining_date')->nullable();
            $table->string('skills')->nullable();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->timestamps();

            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('profile');
    }
}
