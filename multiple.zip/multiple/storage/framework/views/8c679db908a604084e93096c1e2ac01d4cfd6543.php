<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">User Profile <span style="float: right;"><?php echo e(auth()->user()->user_type); ?></span></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>                    

                     <form method="POST" action="<?php echo e(route('profile')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e($profile->name); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="contact" class="col-md-4 col-form-label text-md-right">Contact</label>

                            <div class="col-md-6">
                                <input id="contact" type="text" class="form-control <?php if ($errors->has('contact')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="contact" value="<?php echo e($profile->contact); ?>" required autocomplete="contact" autofocus>

                                <?php if ($errors->has('contact')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($profile->email); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="present_location" class="col-md-4 col-form-label text-md-right">Present Location</label>

                            <div class="col-md-6">
                                <input id="person_location" type="text" class="form-control <?php if ($errors->has('persent_location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('persent_location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="present_location" required autocomplete="new-password">

                                <?php if ($errors->has('present_location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('present_location'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="prefered_location" class="col-md-4 col-form-label text-md-right">Prefered Location</label>

                            <div class="col-md-6">
                                <input id="prefered_location" type="text" class="form-control <?php if ($errors->has('prefered_location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prefered_location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="prefered_location" required autocomplete="new-password">

                                <?php if ($errors->has('prefered_location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('prefered_location'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="education" class="col-md-4 col-form-label text-md-right">Education detail</label>

                            <div class="col-md-6">
                                <input id="education" type="text" class="form-control <?php if ($errors->has('education')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('education'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="education" required autocomplete="new-password">

                                <?php if ($errors->has('education')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('education'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="collage_education" class="col-md-4 col-form-label text-md-right">Collage Education</label>

                            <div class="col-md-6">
                                <input id="collage_education" type="text" class="form-control <?php if ($errors->has('collage_education')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('collage_education'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="collage_education" required autocomplete="new-password">

                                <?php if ($errors->has('collage_education')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('collage_education'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="stream" class="col-md-4 col-form-label text-md-right">Stream</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="stream" required autocomplete="new-password">
                                <?php if ($errors->has('stream')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stream'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="passed_out" class="col-md-4 col-form-label text-md-right">Passed out year</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="passed_out" required autocomplete="new-password">
                                <?php if ($errors->has('passed_out')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('passed_out'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="cgp" class="col-md-4 col-form-label text-md-right">CGP</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="cgp" required autocomplete="new-password">
                                <?php if ($errors->has('cgp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cgp'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="collage_name" class="col-md-4 col-form-label text-md-right">Collage Name</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="collage_name" required autocomplete="new-password">
                                <?php if ($errors->has('collage_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('collage_name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="city" class="col-md-4 col-form-label text-md-right">City</label>

                            <div class="col-md-6">
                                <select id="user_type" class="form-control <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="city" required >
                                    <?php $city=DB::Table('city')
                                    ->select('city.*')
                                    ->get();

                                    foreach($city as $cities){ ?>
                                    <option value="<?php echo e($cities->id); ?>"><?php echo e($cities->name); ?></option>
                                    <?php } ?>
                                </select>   

                                <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <?php if(auth()->user()->user_type=='Experienced'){ ?>
                        <div class="form-group row">
                            <label for="company_details" class="col-md-4 col-form-label text-md-right">Company Details</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="company_details" required autocomplete="new-password">
                                <?php if ($errors->has('company_details')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company_details'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="company_name" class="col-md-4 col-form-label text-md-right">Company Name</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="company_name" required autocomplete="new-password">
                                <?php if ($errors->has('company_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company_name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="role" class="col-md-4 col-form-label text-md-right">Role</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="role" required autocomplete="new-password">
                                <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="joining_date" class="col-md-4 col-form-label text-md-right">Joining Date</label>

                            <div class="col-md-6">
                                <input id="" type="date" class="form-control" name="joining_date" required autocomplete="new-password">
                                <?php if ($errors->has('joining_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('joining_date'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="skills" class="col-md-4 col-form-label text-md-right">Skills</label>

                            <div class="col-md-6">
                                <input id="" type="text" class="form-control" name="skills" required autocomplete="new-password">
                                <?php if ($errors->has('skills')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('skills'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                    <?php } ?>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multiple\resources\views/home.blade.php ENDPATH**/ ?>